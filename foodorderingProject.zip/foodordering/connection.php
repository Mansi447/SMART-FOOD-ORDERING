<?php
$a=mysqli_connect('localhost','root','','book_db');
?>