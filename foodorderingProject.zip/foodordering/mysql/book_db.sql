-- phpMyAdmin SQL Dump
-- version 5.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `book_db`;
USE `book_db`;

-- --------------------------------------------------------

-- Table structure for table `food_orders`
CREATE TABLE `food_orders` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(15) NOT NULL,
  `address` TEXT NOT NULL,
  `restaurant` VARCHAR(255) NOT NULL,
  `food_items` TEXT NOT NULL,
  `quantity` INT NOT NULL,
  `delivery_time` DATETIME NOT NULL,
  `order_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

COMMIT;

